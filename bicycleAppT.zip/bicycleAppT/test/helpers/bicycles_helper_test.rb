require 'test_helper'

class BicyclesHelperTest < ActionView::TestCase
end
