class BicyclesController < ApplicationController
  before_action :set_bicycle, only: [:show, :edit, :update, :destroy]

  # GET /bicycles
  # GET /bicycles.json
  def index
    @bicycles = Bicycle.all
  end
 
  def search
		@bicycles = Bicycle.search params[:query]
		unless @bicycles.empty?
			render 'index'
		else
			flash[:notice] =  'No record matches that search' 
			render 'index'   
		end
  end
  
  def discount
  
  end
  
  def apply_discount
	discount = params[:discount].to_f
	@bicycles = Bicycle.all
	@bicycles.each do |m|
		m.apply_discount(m, discount)
		m.save
	end
	render 'index', notice: "Discount of 10% has been applied"
  end
  
  # GET /bicycles/1
  # GET /bicycles/1.json
  def show
  end

  # GET /bicycles/new
  def new
    @bicycle = Bicycle.new
  end

  # GET /bicycles/1/edit
  def edit
  end

  # POST /bicycles
  # POST /bicycles.json
  def create
    @bicycle = Bicycle.new(bicycle_params)

    respond_to do |format|
      if @bicycle.save
        format.html { redirect_to @bicycle, notice: 'Bicycle was successfully created.' }
        format.json { render :show, status: :created, location: @bicycle }
      else
        format.html { render :new }
        format.json { render json: @bicycle.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /bicycles/1
  # PATCH/PUT /bicycles/1.json
  def update
    respond_to do |format|
      if @bicycle.update(bicycle_params)
        format.html { redirect_to @bicycle, notice: 'Bicycle was successfully updated.' }
        format.json { render :show, status: :ok, location: @bicycle }
      else
        format.html { render :edit }
        format.json { render json: @bicycle.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /bicycles/1
  # DELETE /bicycles/1.json
  def destroy
    @bicycle.destroy
    respond_to do |format|
      format.html { redirect_to bicycles_url, notice: 'Bicycle was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_bicycle
      @bicycle = Bicycle.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def bicycle_params
      params.require(:bicycle).permit(:modelName, :colour, :secondHand, :purchaseCost, :rentCostDay, :frame, :typeOfBicycle, :image)
    end
	
end
