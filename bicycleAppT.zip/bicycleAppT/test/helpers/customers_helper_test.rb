require 'test_helper'

class CustomersHelperTest < ActionView::TestCase
end
