require 'test_helper'

class SearchSuggestionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
