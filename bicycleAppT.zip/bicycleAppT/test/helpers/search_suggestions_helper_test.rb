require 'test_helper'

class SearchSuggestionsHelperTest < ActionView::TestCase
end
