require 'test_helper'

class RentsHelperTest < ActionView::TestCase
end
