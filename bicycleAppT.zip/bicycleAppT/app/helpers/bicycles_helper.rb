module BicyclesHelper
end
