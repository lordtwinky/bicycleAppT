module RentsHelper
end
